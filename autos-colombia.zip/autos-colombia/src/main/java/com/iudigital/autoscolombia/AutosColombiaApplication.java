package com.iudigital.autoscolombia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutosColombiaApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutosColombiaApplication.class, args);
    }

}
